import React, { useState } from 'react';

function Home() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      
      <nav className="bg-white shadow">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <a href="#services" className="text-3xl font-bold text-gray-800 transition duration-500 ease-in-out transform hover:text-blue-600 hover:scale-120 hover:shadow-lg hover:opacity-100">IDEC</a>
          <div className="block lg:hidden">
            <button onClick={toggleMenu} className="text-gray-800 focus:outline-none">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7"></path>
              </svg>
            </button>
          </div>
          <div className={`lg:flex lg:items-center lg:space-x-6 ${isOpen ? 'block' : 'hidden'}`}>
            <a href="#home" className="text-gray-800 mx-2">Home</a>
            <a href="/signup" className="text-gray-800 text-sm mx-1 px-6 py-3 bg-blue-600 text-white font-semibold rounded-full shadow-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75 transition duration-300 ease-in-out">Sign_up</a>
            <a href="/signin" className="text-gray-800 text-sm mx-1 px-6 py-3 bg-blue-600 text-white font-semibold rounded-full shadow-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75 transition duration-300 ease-in-out">Sign_In</a>
          </div>
        </div>
      </nav>

      <header className="flex-1 bg-cover bg-center" style={{ backgroundImage: "url('https://source.unsplash.com/random')" }}>
        <div className="container mx-auto px-4 py-32 text-center">
          <h1 className="text-5xl text-blue-400 font-bold">Welcome to IDEC</h1>
          <p className="text-xl text-gray-400 mt-4 mb-9">We provide amazing services to boost your business.</p>
          <a href="#services" className="text-gray-800 text-lg mx-1 px-6 py-3 bg-blue-600 text-white font-semibold rounded-full shadow-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75 transition duration-300 ease-in-out">Get Started</a>
        </div>
      </header>

      {/* About Section */}
      <section id="about" className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-gray-800 text-center">About Us</h2>
        <p className="mt-4 text-gray-600 text-center max-w-3xl mx-auto">Information Technology & Services, Kolkata</p>
        <p className="mt-4 text-gray-600 text-center max-w-3xl mx-auto">Cyber Security Company || Education || VAPT Services || Innovative Products</p>
      </section>

      {/* Services Section */}
      <section id="services" className="bg-gray-200 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-800 text-center">Our Services</h2>
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-gray-800">Consulting</h3>
              <p className="mt-4 text-gray-600">Shaping Your Idea</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-gray-800">Managing</h3>
              <p className="mt-4 text-gray-600">Shaping Your Ideas Into Action</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-gray-800">Directing</h3>
              <p className="mt-4 text-gray-600">Guiding You Throughout Your Journey</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-gray-800 text-center">Contact Us</h2>
        <p className="mt-4 text-gray-600 text-center max-w-3xl mx-auto">Feel free to reach out to us for more information.</p>
        <div className="mt-8 flex justify-center">
          <form className="w-full max-w-lg">
            <div className="mb-4">
              <input className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none" type="text" placeholder="Your Name" />
            </div>
            <div className="mb-4">
              <input className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none" type="email" placeholder="Your Email" />
            </div>
            <div className="mb-4">
              <textarea className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none" placeholder="Your Message" rows="4"></textarea>
            </div>
            <button type="submit" className="w-full px-4 py-2 bg-blue-500 text-white rounded-lg">Send Message</button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 py-6">
        <div className="container mx-auto px-4 text-center text-gray-400">
          &copy; 2024 IDEC. ~All rights reserved.
        </div>
      </footer>
    </div>
  );
}

export default Home;
