import React, { useEffect, useState } from 'react';

const Admindash = () => {
  const [users, setUsers] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      const currentUserEmail = 'admin@gmail.com';
      const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NmJlZjMwMDBlZTJlOTVmMWNkOWVmYTIiLCJpYXQiOjE3MjM4MDI3NjksImV4cCI6MTcyMzgwNjM2OX0.dMEs-XIqKknzb9SkBw1xE5dQvzhLgKY3XSEMMzkjxfw'; // Replace this with the actual token

      try {
        const url = 'http://192.168.90.17:5000/get-users';
        const response = await fetch(url, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        });

        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        
        
        if (Array.isArray(data)) {
          const adminFound = data.some(user => user.email === currentUserEmail && user.isAdmin);
          setIsAdmin(adminFound);
          setUsers(data);
        } else {
          throw new Error('Unexpected data format');
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>Error: {error}</p>;
  }

  if (!isAdmin) {
    return <p>You do not have access to this page.</p>;
  }

  return (
    <div>
      <div className="relative overflow-x-auto">
        <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
          <thead className="text-xs text-gray-900 uppercase dark:text-gray-400">
            <tr>
              <th scope="col" className="px-6 py-3">
                Full Name
              </th>
              <th scope="col" className="px-6 py-3">
                Email
              </th>
              <th scope="col" className="px-6 py-3">
                Contact
              </th>
              <th scope="col" className="px-6 py-3">
                Address
              </th>
            </tr>
          </thead>
          <tbody>
            {users.length > 0 ? (
              users.map((user) => (
                <tr key={user._id} className="bg-white dark:bg-gray-800">
                  <td
                    scope="row"
                    className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                  >
                    {user.FullName ?? 'N/A'}
                  </td>
                  <td className="px-6 py-4">{user.email ?? 'N/A'}</td>
                  <td className="px-6 py-4">{user.Contact ?? 'N/A'}</td>
                  <td className="px-6 py-4">{user.Address ?? 'N/A'}</td>
                </tr>
              ))
            ) : (
              <tr className="bg-white dark:bg-gray-800">
                <td colSpan="4" className="px-6 py-4 text-center">
                  No data available
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Admindash;
