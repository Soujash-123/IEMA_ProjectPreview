import React, { createContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

// Create Auth Context
export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState({ isAuthenticated: false, user: null });
  const navigate = useNavigate();

  useEffect(() => {
    // Check for token on initial load
    const token = localStorage.getItem('token');
    if (token) {
      // Implement your logic to verify token here
      setAuth({ isAuthenticated: true });
    } else {
      setAuth({ isAuthenticated: false });
    }
  }, []);

  const login = (user) => {
    setAuth({ isAuthenticated: true, user });
    localStorage.setItem('token', user.token); // Save token
    navigate(user.email === 'admin@gmail.com' ? '/admin-dashboard' : '/dashboard');
  };

  const logout = () => {
    setAuth({ isAuthenticated: false, user: null });
    localStorage.removeItem('token'); // Remove token
    navigate('/signin');
  };

  return (
    <AuthContext.Provider value={{ auth, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
