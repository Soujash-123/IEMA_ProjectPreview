import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Signin from './pages/Signin';
import Signup from './pages/Signup';
import Home from './pages/Home';
import Userdash from './pages/Userdash';
import './App.css';
import Admindash from './pages/Admindash';
import Forgot from './pages/Forgot';
import Changepass from './pages/Changepass';

function App() {
  
  return (
    <Router>
      <Routes>
        <Route path="/signin" element={<Signin />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/dashboard" element={<Userdash />} />
        <Route path="/admin-dashboard" element={<Admindash />} />
        <Route path="/forget-password" element={<Forgot />} />
        <Route path="/change-password" element={<Changepass />} />
     
        <Route path="/" element={<Home />} /> 
      </Routes>
    </Router>
  );
}

export default App;
