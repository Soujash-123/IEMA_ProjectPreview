const express = require('express');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const connectDB = require('./DB/db');
const User = require('./model/user.model');
const adminMiddleware = require('./middlewares/adminMiddleware');
const signupController = require('./controller/signupController');
const loginController = require('./controller/loginController'); // Fixed the import path
const adminController = require('./controller/adminController');
const allDataController = require('./controller/allDataController');
const forgetPasswordController = require('./controller/forgetPasswordController');
const verifyOtpController = require('./controller/verifyOtpController');
const resetPasswordController = require('./controller/resetPasswordController'); // Added import

const app = express();

require('dotenv').config();

const PORT = process.env.PORT || 3000;

connectDB();

app.use(express.json());
app.use(cors());

const JWT_SECRET = process.env.KEY;

// Signup endpoint
app.post('/signup', signupController);

// Login endpoint
app.post('/login', loginController);

// Admin-only signup
app.post('/admin-only', adminMiddleware, adminController);

// Get user's data
app.get('/get-users', adminMiddleware, allDataController);

// Forget password
app.post('/forget-password', forgetPasswordController);

// Reset password (changed to POST method)
app.post('/changePassword', resetPasswordController); // Changed to POST method

// Match OTP
app.post('/match-otp', verifyOtpController);

// Global error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!' });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
