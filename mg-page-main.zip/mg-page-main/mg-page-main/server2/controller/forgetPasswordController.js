const nodemailer = require('nodemailer');
const crypto = require('crypto');
const User = require('../model/user.model');

const { ADMIN_EMAIL, MY_GMAIL, MY_PASSWORD } = process.env;

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: MY_GMAIL,
    pass: MY_PASSWORD,
  },
});

const generateOTP = () => {
  const otpBuffer = crypto.randomBytes(3); 
  return otpBuffer.toString('hex').toUpperCase().slice(0, 6);
};

const forgetPasswordController = async (req, res) => {
  const { email } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const otp = generateOTP();

    user.resetToken = otp;
    user.resetTokenExpire = Date.now() + 180000; 

    await user.save();

    const otpMessage = `
      <p>You requested an OTP for password reset. Use the following OTP to proceed:</p>
      <p><strong>${otp}</strong></p>
      <p>This OTP is valid for 3 minutes.</p>
    `;

    await transporter.sendMail({
      from: ADMIN_EMAIL,
      to: email,
      subject: 'Your OTP Code',
      html: otpMessage,
    });

    res.status(200).json({ message: 'OTP sent successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = forgetPasswordController;
